﻿namespace CS2SKINAppWeb.NovaPasta4
{
    public class Skins
    {
    }
}
