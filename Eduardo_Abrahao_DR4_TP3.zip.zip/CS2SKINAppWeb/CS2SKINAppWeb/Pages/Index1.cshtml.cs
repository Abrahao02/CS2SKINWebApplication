using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CS2SKINAppWeb.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
